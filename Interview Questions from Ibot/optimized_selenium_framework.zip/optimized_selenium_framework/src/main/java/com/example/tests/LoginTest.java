
package com.example.tests;

import com.example.pages.LoginPage;
import com.example.utils.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class LoginTest {
    WebDriver driver;
    LoginPage loginPage;

    @BeforeMethod
    public void setup() {
        driver = DriverFactory.createDriver();
        loginPage = new LoginPage(driver);
    }

    @Test(groups = {"smoke"})
    public void testLogin() {
        driver.get("https://example.com/login");
        loginPage.login("admin", "admin123");
    }

    @AfterMethod
    public void tearDown() {
        DriverFactory.quitDriver();
    }
}
