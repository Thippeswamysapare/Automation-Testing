package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import factory.DriverFactory;
import pages.LoginPage;

public class LoginTest {

    @BeforeMethod
    public void setup() {
        WebDriver driver = new ChromeDriver();
        DriverFactory.setDriver(driver);
        driver.get("https://example.com/login");
    }

    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage();
        loginPage.login("admin", "admin123");
    }

    @AfterMethod
    public void tearDown() {
        DriverFactory.quitDriver();
    }
}