package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.*;
import listeners.CustomListener;

public class SampleTest {
    WebDriver driver;
    EventFiringWebDriver eventDriver;

    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        eventDriver = new EventFiringWebDriver(driver);
        eventDriver.register(new CustomListener());
        eventDriver.get("https://example.com");
    }

    @Test
    public void testClick() {
        WebElement element = eventDriver.findElement(By.tagName("h1"));
        element.click();
    }

    @AfterMethod
    public void tearDown() {
        CustomListener.flushReport();
        eventDriver.quit();
    }
}
