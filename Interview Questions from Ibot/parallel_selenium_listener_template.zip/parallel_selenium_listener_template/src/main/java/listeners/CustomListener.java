package listeners;

import org.openqa.selenium.*;
import org.openqa.selenium.support.events.WebDriverEventListener;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class CustomListener implements WebDriverEventListener {
    private static ExtentReports extent;
    private static ExtentTest test;

    static {
        ExtentHtmlReporter reporter = new ExtentHtmlReporter("test-output/ExtentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
        test = extent.createTest("Selenium Event Logging");
    }

    @Override
    public void beforeClickOn(WebElement element, WebDriver driver) {
        test.info("Trying to click on: " + element.toString());
    }

    @Override
    public void afterClickOn(WebElement element, WebDriver driver) {
        test.info("Clicked on: " + element.toString());
    }

    @Override
    public void onException(Throwable throwable, WebDriver driver) {
        test.fail("Exception occurred: " + throwable.getMessage());
    }

    @Override
    public void beforeNavigateTo(String url, WebDriver driver) {
        test.info("Navigating to: " + url);
    }

    @Override
    public void afterNavigateTo(String url, WebDriver driver) {
        test.info("Navigated to: " + url);
    }

    // Other methods can be overridden as needed

    public static void flushReport() {
        extent.flush();
    }

    // Empty implementations for unused methods
    public void beforeAlertAccept(WebDriver driver) {}
    public void afterAlertAccept(WebDriver driver) {}
    public void afterAlertDismiss(WebDriver driver) {}
    public void beforeAlertDismiss(WebDriver driver) {}
    public void beforeNavigateBack(WebDriver driver) {}
    public void afterNavigateBack(WebDriver driver) {}
    public void beforeNavigateForward(WebDriver driver) {}
    public void afterNavigateForward(WebDriver driver) {}
    public void beforeNavigateRefresh(WebDriver driver) {}
    public void afterNavigateRefresh(WebDriver driver) {}
    public void beforeChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {}
    public void afterChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {}
    public void beforeFindBy(By by, WebElement element, WebDriver driver) {}
    public void afterFindBy(By by, WebElement element, WebDriver driver) {}
    public void beforeScript(String script, WebDriver driver) {}
    public void afterScript(String script, WebDriver driver) {}
}
